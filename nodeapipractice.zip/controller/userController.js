var usermodel = require('../Models/userModel.js')
var passhash = require('password-hash')
var jwt=require('jsonwebtoken')
var config=require('../config/config.js')
const bearerToken = require('express-bearer-token');

exports.create = (req, res) => {
    var token = req.body.token || req.query.token || req.headers['x-access-token'];
    console.log('pill')
    console.log(jwt.verify(req.token,config.secrete,(err,re)=>{
        if(err)
        {
            console.log(err)
        }
        console.log(re)
    }));

    
    const users = new usermodel({
        Name: req.body.Name,
        Email: req.body.Email,
        password: passhash.generate(req.body.password)
    });
    console.log(users);
    usermodel.findOne({ Email: req.body.Email }, (err, user) => {
        if (err) {
        }
        console.log('lolll')
        console.log(user);

       
        if (!user) {
            
            users.save().then(data => {
                console.log(data);
                res.send(data);
            }).catch(er => {
                console.log('some thisn happened');
            })
        }
        else {
            res.json({ "message": "user Already exists" })
          
        }
    })

 }

exports.login = (req, res) => {

    console.log(req.body.Email);
    const users = new usermodel({
        Email: req.body.Email
    })
   usermodel.findOne({ Email: req.body.Email }, (err, user) => {
        if (err) {
        }
        console.log('lolll')
        console.log(user);

        if (user.Email === req.body.Email && passhash.verify(req.body.password,user.password) ) {
            console.log('email and password verified');
            const payload={
                admin:'admin'
            }
            var token=jwt.sign(payload,config.secrete,{expiresIn:12})
          
           console.log(token)

           res.send({users,token});

        }
    })


}