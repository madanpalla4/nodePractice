
module.exports={
    url:'mongodb://localhost:27017/nodeTest2',
    secrete:'pallaMadanKumar'
}