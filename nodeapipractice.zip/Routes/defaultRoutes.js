const users=require('../controller/userController.js')

module.exports=(app)=>{
    app.get('/',(req,res)=>{
       res.json({"Welcome":"Palla"})
    })

    app.post('/createUser',users.create);

    app.post('/login',users.login)
}