const mongoose=require('mongoose');
const crypto=require('crypto')

const userschema=mongoose.Schema({
    Name:String,
    Email:String,
    password:String
   
},{timestamps:true})

userschema.methods.setPassword=(pass)=>{
this.password=crypto.randomBytes(16).toString('hex');


this.password = crypto.pbkdf2Sync(pass, this.password,  
1000, 64, 'sha512').toString('hex'); 

console.log(this.password)
}

userschema.methods.ValidPassword=(password)=>{
    var hash= crypto.pbkdf2Sync(password,  
        this.salt, 1000, 64, 'sha512').toString('hex'); 
        return this.hash === hash; 
}

module.exports=mongoose.model('Users',userschema);